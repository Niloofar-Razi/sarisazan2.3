# سریع‌سازان البرز - سیستم مدیریت پروژه

## Overview
This project is a comprehensive construction project management application developed in Farsi. Its primary purpose is to streamline project tracking, material management, tendering processes, and internal communication for construction firms. Key capabilities include managing construction projects, tracking materials like bitumen, daily reporting, tender management with SLA alerts, an analytical dashboard, and an internal messaging system. The ambition is to provide a robust, localized solution for construction project management in Farsi-speaking markets, enhancing efficiency and communication.

## User Preferences
- All user interface elements and content should be in Farsi.
- The application should utilize the Jalali (Persian) calendar system for all date-related functionalities.
- The default currency for all financial transactions and displays should be Iranian Rial (ریال).
- The user interface design must support Right-to-Left (RTL) directionality consistently across all components.

## System Architecture

### UI/UX Decisions
- **Language & Direction**: Farsi language with RTL layout.
- **Date & Currency**: Jalali calendar and Iranian Rial.
- **Components**: Utilizes Radix UI and shadcn/ui for a modern and accessible design system.
- **Design Approach**: Focus on clear, intuitive navigation and data presentation, especially for complex features like tender management and alerts.
- **AI Assistant**: Free token-based search with Persian-aware text normalization, punctuation handling, and stop words filtering. Context-aware responses for projects, alerts, tenders, and statements.

### Technical Implementations
- **Frontend**: Developed with React, Vite, TypeScript, and styled using Tailwind CSS. State management is handled by TanStack Query (React Query).
- **Backend**: Built with Express.js and TypeScript, providing a robust API layer.
- **Database**: PostgreSQL, managed with Drizzle ORM.
- **File Uploads**: `multer` is used for handling file attachments.
- **Real-time Updates**: Hot Module Replacement (HMR) is configured for seamless development.
- **Performance**: Extensive use of `useMemo` for optimizing data-heavy components.

### Feature Specifications
- **Project Management**: CRUD, progress tracking, search, filtering.
- **Material Management (Bitumen)**: Project-specific bitumen record management with CSV export.
- **Progress Statements**: Three-tab interface for Statements, Adjustments, and Bitumen Differences with CRUD, project-based filtering, status tracking, financial calculation, soft delete, and negative amounts support.
- **Tender Management**: Comprehensive CRUD, automated SLA alerts, intelligent sorting, and status tracking.
- **Alert Management**: Centralized listing, advanced filtering, manual creation, status changes, user assignment, and CSV export. Automated hourly alerts for overdue tenders, nearing deadlines, and underperforming projects.
- **Lab Sheets Management**: CRUD for various sheet types, file attachment support (up to 5 files), advanced filtering, status tracking, CSV export, and soft delete.
- **Internal Messaging System**: Supports Direct, Group, and Project-specific conversations with text, file attachments, read/unread status, search, and member management.
- **Reporting**: Daily activity reports and execution progress reports.
- **Roles & Permissions**: Role-based access control with predefined and custom roles, granular permissions, and user profile management.
- **Dashboard**: Real database-driven KPIs (Total Projects, Active Projects, Open Alerts, Average Project Progress), "هشدارها" tab for open alerts, and "تحلیل داده" tab with charts (alert distribution, project status, individual project progress) powered by Recharts.
- **Global Search**: Integrated global search bar in header for project titles and contract numbers.

### System Design Choices
- **Monorepo Structure**: Organized into `client/`, `server/`, and `shared/` directories.
- **Database Schema**: Comprehensive schema including `users`, `projects`, `bitumen_records`, `statements`, `adjustments`, `bitumen_diffs`, `tenders`, `alerts`, `user_projects`, `sheets`, `sheet_files`, `conversations`, `conversation_members`, `messages`, `message_files`, `message_reads`.
- **Integrated Server**: Express server serves both API endpoints and frontend assets on port 5000.
- **Automated Tasks**: Scheduled tasks (e.g., hourly checks for alerts) integrated into the backend.

## External Dependencies
- **Database**: PostgreSQL.
- **ORM**: Drizzle ORM.
- **Node.js Driver**: `pg`.
- **Frontend Libraries**: React, Vite, TypeScript, Tailwind CSS, Radix UI, shadcn/ui, TanStack Query (React Query), Recharts.
- **Backend Libraries**: Express.js, TypeScript.
- **File Upload Middleware**: `multer`.

## Replit Environment Setup

### Development Setup
- **Runtime**: Node.js 20
- **Package Manager**: npm
- **Development Server**: Runs on port 5000 (both frontend and backend served together)
- **Database**: PostgreSQL (Replit built-in, managed via DATABASE_URL environment variable)

### Prerequisites
1. **Database Configuration**: Ensure the DATABASE_URL environment variable is set. This is automatically configured when using Replit's built-in PostgreSQL database. The application will fail to start without this.
2. **Install Dependencies**: Run `npm install` to install all required packages before running any other commands.

### Running the Application
1. Install dependencies: `npm install`
2. Initialize/update database schema: `npm run db:push`
3. Development mode: `npm run dev` (already configured as a workflow)
4. Build for production: `npm run build`
5. Start production server: `npm start`

### Deployment Configuration
- **Type**: Autoscale deployment
- **Build command**: `npm run build`
- **Run command**: `npm start`
- **Port**: 5000 (Express serves both API and frontend)

### Important Notes
- The Vite development server is configured to allow all hosts (`allowedHosts: true`) to work with Replit's proxy
- HMR (Hot Module Replacement) is configured for WSS protocol on port 443
- Permissions and roles are automatically initialized on first server start after the database connection succeeds
- Auto-alert scheduler runs hourly to check for tender deadlines and project alerts
- The application serves both API endpoints and frontend from a single Express server on port 5000

## Recent Changes

### October 16, 2025 - GitHub Import to Replit Completed
- Successfully imported project from GitHub repository into Replit environment
- Installed Node.js 20 runtime and all npm dependencies (494 packages)
- Connected to Replit's built-in PostgreSQL database (DATABASE_URL configured)
- Initialized database schema using Drizzle ORM (`npm run db:push`)
- Configured development workflow to run on port 5000 with webview output
- Set up deployment configuration:
  - Deployment target: Autoscale
  - Build command: `npm run build`
  - Run command: `npm start`
- Verified application is fully functional:
  - Backend Express server running successfully on port 5000
  - Frontend React/Vite application accessible with Persian RTL interface
  - Database schema initialized with all tables
  - Permissions and roles system initialized (6 roles, 34 permissions)
  - Auto-alert scheduler activated for hourly checks
  - Vite HMR (Hot Module Replacement) working correctly

### October 15, 2025 - New Task Management & Navigation Features
- **Enhanced Database Schema**: Added comprehensive tables for enhanced task management system:
  - `tasks`: Extended with project linking, assignee, attachments, reminders, confirmation workflow, completion tracking
  - `task_attachments`: File attachments for tasks
  - `calendar_notes`: Daily notes linked to Jalali calendar dates
  - `sticky_notes` & `sticky_note_items`: Colorful sticky notes with checklist functionality
  - `letters` & `letter_recipients`: Internal letter/message system with inbox/outbox/project inbox

- **Improved Navigation & UI**:
  - Enhanced sidebar with new menu items: وظایف (Tasks), تقویم (Calendar), یادداشت‌ها (Notes), نامه‌ها (Letters)
  - Dynamic color scheme on hover with deeper colors for better UX
  - Updated PageHeader with colored indicator bar and "نیاز به اقدام" (needs action) badge
  - Responsive RTL layout maintained across all new components

- **Task Management System**:
  - Comprehensive task list with checkbox, strikethrough, and priority badges
  - Filter options: All, Pending, Completed, Today
  - "Completed today" congratulatory card showing count of tasks finished today
  - Real-time task completion toggle with proper timestamp tracking
  - Priority levels: Low, Medium, High, Urgent with color-coded badges
  - Reminder and confirmation workflow indicators

- **API Enhancements**:
  - `/api/needs-action`: Returns count and details of items requiring attention
  - `/api/tasks` PATCH endpoint: Properly sets completedAt timestamp on task completion
  - Fixed critical bugs in date comparison for reminders (using PostgreSQL DATE() function)
  - Deduplication of tasks to prevent double-counting in needs-action badge

- **Pages Created** (Ready for full implementation):
  - TasksPage: Functional task list with all features
  - CalendarPage: Jalali calendar placeholder
  - NotesPage: Sticky notes placeholder
  - LettersPage: Letters/messaging placeholder

### October 15, 2025 - Initial Replit Setup
- Successfully imported GitHub project into Replit environment
- Installed Node.js 20 runtime and all npm dependencies
- Connected to Replit's built-in PostgreSQL database
- Initialized database schema using Drizzle ORM (`npm run db:push`)
- Configured development workflow to run on port 5000
- Set up deployment configuration for autoscale deployment
- Verified application is fully functional with:
  - Backend Express server running successfully
  - Frontend React/Vite application accessible
  - Database schema initialized with all tables
  - Permissions and roles system initialized (6 roles, 34 permissions)
  - Auto-alert scheduler activated
  - Persian (Farsi) RTL interface working correctly