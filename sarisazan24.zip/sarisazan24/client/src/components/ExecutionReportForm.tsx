import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";

const WEATHER_CONDITIONS = [
  { value: "sunny", label: "آفتابی" },
  { value: "cloudy", label: "ابری" },
  { value: "rainy", label: "بارانی" },
  { value: "snowy", label: "برفی" },
  { value: "stormy", label: "طوفانی" },
];

const MACHINERY_TYPES = [
  "لودر",
  "بیل مکانیکی",
  "بولدوزر",
  "گریدر",
  "غلتک لاستیکی",
  "غلتک آهنی",
  "فینیشر",
  "بیرپاش",
  "تانکر آب",
  "کامیون/تریلی",
  "جرثقیل",
  "میکسر بتن",
  "کمپرسور",
  "مینی‌لودر",
  "سایر...",
];

const reportSchema = z.object({
  reportDate: z.string(),
  weatherCondition: z.string().min(1, "انتخاب وضعیت آب و هوا الزامی است"),
  minTemperature: z.coerce.number({
    required_error: "حداقل دما الزامی است",
    invalid_type_error: "عدد معتبر وارد کنید"
  }).min(-30, "حداقل دما باید -۳۰ یا بیشتر باشد").max(60, "حداقل دما باید ۶۰ یا کمتر باشد"),
  maxTemperature: z.coerce.number({
    required_error: "حداکثر دما الزامی است",
    invalid_type_error: "عدد معتبر وارد کنید"
  }).min(-30, "حداکثر دما باید -۳۰ یا بیشتر باشد").max(60, "حداکثر دما باید ۶۰ یا کمتر باشد"),
  projectId: z.string().min(1, "انتخاب پروژه الزامی است"),
  activityDescription: z.string().min(1, "شرح فعالیت الزامی است."),
  soilMechanicsLab: z.string().optional(),
  workerCount: z.coerce.number({
    required_error: "تعداد کارگر الزامی است",
    invalid_type_error: "عدد معتبر وارد کنید"
  }).min(0, "تعداد کارگر باید ۰ یا بیشتر باشد"),
  inspectionDescription: z.string().optional(),
  existingProblems: z.string().optional(),
}).refine((data) => data.maxTemperature >= data.minTemperature, {
  message: "حداکثر دما باید بزرگ‌تر یا مساوی حداقل باشد.",
  path: ["maxTemperature"],
});

type ReportFormData = z.infer<typeof reportSchema>;

export function ExecutionReportForm({ supervisorId, supervisorName }: { supervisorId: string; supervisorName: string }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [machinery, setMachinery] = useState<Array<{ name: string; count: number; customName?: string }>>([{ name: "", count: 1 }]);
  const [materials, setMaterials] = useState<Array<{ serviceCount: number; materialType: string; tonnage: number }>>([{ serviceCount: 1, materialType: "", tonnage: 0 }]);
  const [persianDate, setPersianDate] = useState("");

  useEffect(() => {
    const formattedDate = toPersianDigits(format(new Date(), 'yyyy/MM/dd'));
    setPersianDate(formattedDate);
  }, []);

  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("Failed to fetch projects");
      return response.json();
    },
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset,
  } = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      reportDate: new Date().toISOString().split('T')[0],
      minTemperature: 15,
      maxTemperature: 25,
      workerCount: 0,
    },
  });

  const minTemp = watch("minTemperature");
  const maxTemp = watch("maxTemperature");

  const createReportMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/reports/execution", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "ثبت گزارش با خطا مواجه شد.");
      }
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "موفقیت",
        description: data.message || "گزارش با موفقیت ثبت شد.",
      });
      queryClient.invalidateQueries({ queryKey: ["execution-reports"] });
      reset();
      setMachinery([{ name: "", count: 1 }]);
      setMaterials([{ serviceCount: 1, materialType: "", tonnage: 0 }]);
    },
    onError: (error: Error) => {
      toast({
        title: "خطا",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ReportFormData) => {
    const validMachinery = machinery
      .filter(m => m.name)
      .map(m => ({
        machineryName: m.name === "سایر..." ? m.customName || "" : m.name,
        count: m.count,
      }));

    if (validMachinery.some(m => !m.machineryName)) {
      toast({
        title: "خطا",
        description: "نام دستگاه را وارد کنید.",
        variant: "destructive",
      });
      return;
    }

    const validMaterials = materials.filter(m => m.materialType && m.serviceCount > 0);

    createReportMutation.mutate({
      report: {
        ...data,
        supervisorId,
        reportDate: new Date(data.reportDate).toISOString(),
      },
      machinery: validMachinery,
      materials: validMaterials,
    });
  };

  const addMachinery = () => {
    setMachinery([...machinery, { name: "", count: 1 }]);
  };

  const removeMachinery = (index: number) => {
    setMachinery(machinery.filter((_, i) => i !== index));
  };

  const addMaterial = () => {
    setMaterials([...materials, { serviceCount: 1, materialType: "", tonnage: 0 }]);
  };

  const removeMaterial = (index: number) => {
    setMaterials(materials.filter((_, i) => i !== index));
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" dir="rtl">
      <Card>
        <CardHeader>
          <CardTitle>فرم گزارش روزانه اجرا</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reportDate">تاریخ شمسی</Label>
              <Input
                id="reportDate"
                type="text"
                value={persianDate}
                onChange={(e) => setPersianDate(e.target.value)}
                className="text-right"
                placeholder="۱۴۰۴/۰۷/۱۲"
              />
              <input
                type="hidden"
                {...register("reportDate")}
              />
              {errors.reportDate && (
                <p className="text-sm text-red-500">{errors.reportDate.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="supervisor">سرپرست کارگاه</Label>
              <Input
                id="supervisor"
                value={supervisorName}
                readOnly
                disabled
                className="text-right bg-muted"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="weatherCondition">شرایط آب‌وهوا</Label>
            <Select onValueChange={(value) => setValue("weatherCondition", value)}>
              <SelectTrigger id="weatherCondition">
                <SelectValue placeholder="انتخاب کنید..." />
              </SelectTrigger>
              <SelectContent>
                {WEATHER_CONDITIONS.map((condition) => (
                  <SelectItem key={condition.value} value={condition.value}>
                    {condition.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.weatherCondition && (
              <p className="text-sm text-red-500">{errors.weatherCondition.message}</p>
            )}
          </div>

          <div className="space-y-4">
            <Label>دما (درجه سانتی‌گراد)</Label>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="minTemperature" className="text-sm">حداقل</Label>
                <Input
                  id="minTemperature"
                  type="number"
                  {...register("minTemperature", { valueAsNumber: true })}
                  className="text-right"
                />
                <Slider
                  value={[minTemp]}
                  onValueChange={(value) => setValue("minTemperature", value[0])}
                  min={-30}
                  max={60}
                  step={1}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maxTemperature" className="text-sm">حداکثر</Label>
                <Input
                  id="maxTemperature"
                  type="number"
                  {...register("maxTemperature", { valueAsNumber: true })}
                  className="text-right"
                />
                <Slider
                  value={[maxTemp]}
                  onValueChange={(value) => setValue("maxTemperature", value[0])}
                  min={-30}
                  max={60}
                  step={1}
                />
              </div>
            </div>
            {errors.maxTemperature && (
              <p className="text-sm text-red-500">{errors.maxTemperature.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectId">پروژه</Label>
            <Select onValueChange={(value) => setValue("projectId", value)}>
              <SelectTrigger id="projectId">
                <SelectValue placeholder="انتخاب پروژه..." />
              </SelectTrigger>
              <SelectContent>
                {projects?.map((project: any) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.projectId && (
              <p className="text-sm text-red-500">{errors.projectId.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="activityDescription">شرح فعالیت‌ها *</Label>
            <Textarea
              id="activityDescription"
              {...register("activityDescription")}
              rows={4}
              className="text-right"
              placeholder="شرح کامل فعالیت‌های انجام شده را وارد کنید..."
            />
            {errors.activityDescription && (
              <p className="text-sm text-red-500">{errors.activityDescription.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="soilMechanicsLab">آزمایشگاه مکانیک خاک (اختیاری)</Label>
            <Input
              id="soilMechanicsLab"
              {...register("soilMechanicsLab")}
              className="text-right"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="workerCount">تعداد کارگر</Label>
            <Input
              id="workerCount"
              type="number"
              min="0"
              {...register("workerCount", { valueAsNumber: true })}
              className="text-right"
            />
          </div>

          <div className="space-y-2">
            <Label>ماشین‌آلات فعال</Label>
            {machinery.map((item, index) => (
              <div key={index} className="flex gap-2 items-start">
                <Select
                  value={item.name}
                  onValueChange={(value) => {
                    const updated = [...machinery];
                    updated[index].name = value;
                    setMachinery(updated);
                  }}
                >
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="انتخاب دستگاه..." />
                  </SelectTrigger>
                  <SelectContent>
                    {MACHINERY_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {item.name === "سایر..." && (
                  <Input
                    placeholder="نام دستگاه..."
                    value={item.customName || ""}
                    onChange={(e) => {
                      const updated = [...machinery];
                      updated[index].customName = e.target.value;
                      setMachinery(updated);
                    }}
                    className="flex-1 text-right"
                  />
                )}
                <Input
                  type="number"
                  min="1"
                  value={item.count}
                  onChange={(e) => {
                    const updated = [...machinery];
                    updated[index].count = parseInt(e.target.value) || 1;
                    setMachinery(updated);
                  }}
                  className="w-24 text-right"
                  placeholder="تعداد"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  onClick={() => removeMachinery(index)}
                  disabled={machinery.length === 1}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" onClick={addMachinery} className="w-full">
              <Plus className="w-4 h-4 ml-2" />
              افزودن دستگاه
            </Button>
          </div>

          <div className="space-y-2">
            <Label>سرویس و تناژ مصالح</Label>
            {materials.map((item, index) => (
              <div key={index} className="flex gap-2 items-start">
                <Input
                  type="number"
                  min="1"
                  value={item.serviceCount}
                  onChange={(e) => {
                    const updated = [...materials];
                    updated[index].serviceCount = parseInt(e.target.value) || 1;
                    setMaterials(updated);
                  }}
                  className="w-24 text-right"
                  placeholder="تعداد"
                />
                <Input
                  value={item.materialType}
                  onChange={(e) => {
                    const updated = [...materials];
                    updated[index].materialType = e.target.value;
                    setMaterials(updated);
                  }}
                  className="flex-1 text-right"
                  placeholder="نوع مصالح..."
                />
                <Input
                  type="number"
                  min="0"
                  value={item.tonnage}
                  onChange={(e) => {
                    const updated = [...materials];
                    updated[index].tonnage = parseFloat(e.target.value) || 0;
                    setMaterials(updated);
                  }}
                  className="w-32 text-right"
                  placeholder="تناژ"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  onClick={() => removeMaterial(index)}
                  disabled={materials.length === 1}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" onClick={addMaterial} className="w-full">
              <Plus className="w-4 h-4 ml-2" />
              افزودن مصالح
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="inspectionDescription">شرح بازدید</Label>
            <Textarea
              id="inspectionDescription"
              {...register("inspectionDescription")}
              rows={2}
              className="text-right"
              placeholder="شرح بازدید را وارد کنید..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="existingProblems">مشکلات موجود</Label>
            <Textarea
              id="existingProblems"
              {...register("existingProblems")}
              rows={3}
              className="text-right"
              placeholder="مشکلات موجود را شرح دهید..."
            />
          </div>

          <Button type="submit" className="w-full" disabled={createReportMutation.isPending}>
            {createReportMutation.isPending ? "در حال ثبت..." : "ثبت گزارش"}
          </Button>
        </CardContent>
      </Card>
    </form>
  );
}
