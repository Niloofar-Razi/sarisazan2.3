import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, FileText } from "lucide-react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";

export default function ReportsPage() {
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    setCurrentDate(new Date());
  }, []);

  const formattedDate = toPersianDigits(format(currentDate, 'yyyy/MM/dd'));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">گزارش روزانه دفتر فنی</h1>
        <p className="text-muted-foreground">ثبت و مدیریت گزارش‌های روزانه دفتر فنی</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            فرم گزارش روزانه دفتر فنی
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tech-date">تاریخ</Label>
              <Input 
                id="tech-date" 
                type="text" 
                defaultValue={formattedDate} 
                placeholder={formattedDate} 
                data-testid="input-tech-date" 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tech-project">پروژه</Label>
              <Input id="tech-project" type="text" placeholder="انتخاب پروژه" data-testid="input-tech-project" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="tech-description">شرح فعالیت‌های فنی</Label>
            <Textarea 
              id="tech-description" 
              placeholder="شرح کامل فعالیت‌های فنی انجام شده در دفتر..." 
              rows={5}
              data-testid="input-tech-description"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="tech-notes">یادداشت‌ها</Label>
            <Textarea 
              id="tech-notes" 
              placeholder="یادداشت‌های اضافی..." 
              rows={3}
              data-testid="input-tech-notes"
            />
          </div>
          <Button data-testid="button-submit-tech-report">
            <Plus className="w-4 h-4 ml-2" />
            ثبت گزارش دفتر فنی
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>لیست گزارش‌های دفتر فنی</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            هنوز گزارشی ثبت نشده است
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
