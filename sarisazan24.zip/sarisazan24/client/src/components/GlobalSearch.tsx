import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, FolderKanban } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface Project {
  id: string;
  title: string;
  contractNumber: string;
  progress: number;
}

export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();
  
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const filteredProjects = projects.filter((project) => {
    const query = searchQuery.toLowerCase();
    return (
      project.title.toLowerCase().includes(query) ||
      project.contractNumber.toLowerCase().includes(query)
    );
  });

  const handleSelect = (projectId: string) => {
    setOpen(false);
    setSearchQuery("");
    navigate(`/projects/${projectId}`);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative w-full max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی پروژه..."
            className="pr-10"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command>
          <CommandList>
            {searchQuery.length > 0 ? (
              <>
                {filteredProjects.length === 0 ? (
                  <CommandEmpty>هیچ پروژه‌ای یافت نشد.</CommandEmpty>
                ) : (
                  <CommandGroup heading="پروژه‌ها">
                    {filteredProjects.slice(0, 8).map((project) => (
                      <CommandItem
                        key={project.id}
                        value={project.id}
                        onSelect={() => handleSelect(project.id)}
                        className="cursor-pointer"
                      >
                        <FolderKanban className="ml-2 h-4 w-4" />
                        <div className="flex flex-col flex-1">
                          <span className="font-medium">{project.title}</span>
                          <span className="text-xs text-muted-foreground">
                            قرارداد: {project.contractNumber} • پیشرفت: {project.progress}%
                          </span>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                )}
              </>
            ) : (
              <div className="p-4 text-sm text-muted-foreground text-center">
                نام یا شماره قرارداد پروژه را وارد کنید
              </div>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
