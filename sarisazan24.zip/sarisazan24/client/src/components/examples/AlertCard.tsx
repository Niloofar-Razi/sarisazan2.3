import AlertCard from '../AlertCard';

export default function AlertCardExample() {
  return (
    <div className="p-4 space-y-3 max-w-2xl">
      <AlertCard
        id="1"
        title="گزارش روزانه تایید شد"
        message="گزارش روزانه پروژه آزادراه تهران-شمال مورخ 1402/10/15 توسط مدیر پروژه تایید شد."
        type="success"
        project="آزادراه تهران-شمال"
        date="1402/10/15 - 14:30"
        isRead={false}
        onMarkRead={(id) => console.log('Mark read:', id)}
      />
      <AlertCard
        id="2"
        title="هشدار تاخیر در پروژه"
        message="پروژه بزرگراه صیاد شیرازی با تاخیر 5 روزه مواجه است. لطفاً اقدامات لازم را انجام دهید."
        type="warning"
        project="بزرگراه صیاد شیرازی"
        date="1402/10/14 - 09:15"
        isRead={true}
        onMarkRead={(id) => console.log('Mark read:', id)}
      />
    </div>
  );
}
