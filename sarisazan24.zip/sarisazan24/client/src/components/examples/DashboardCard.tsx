import DashboardCard from '../DashboardCard';
import { FolderKanban } from 'lucide-react';

export default function DashboardCardExample() {
  return (
    <div className="p-4">
      <DashboardCard
        title="پروژه‌های فعال"
        value="12"
        description="پروژه در حال اجرا"
        icon={FolderKanban}
        trend={{ value: 8, isPositive: true }}
      />
    </div>
  );
}
