import DailyReportForm from '../DailyReportForm';

export default function DailyReportFormExample() {
  return (
    <div className="p-4 max-w-2xl">
      <DailyReportForm onSubmit={(data) => console.log('Report submitted:', data)} />
    </div>
  );
}
