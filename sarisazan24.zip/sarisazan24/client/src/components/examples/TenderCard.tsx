import TenderCard from '../TenderCard';

export default function TenderCardExample() {
  return (
    <div className="p-4 max-w-md">
      <TenderCard
        id="1"
        title="مناقصه احداث پل بتنی"
        city="تهران"
        amount="25,000"
        deadline="1402/10/25"
        organizer="شهرداری منطقه 5"
        companies={["سازه پارس", "بنیان سازه", "راه و ساختمان البرز"]}
        isReviewed={false}
        daysUntilDeadline={2}
        onReview={(id) => console.log('Review tender:', id)}
      />
    </div>
  );
}
