import { Home, FolderKanban, FileText, Droplet, ClipboardList, Gavel, Bell, Users, Shield, User as UserIcon, Inbox, ChevronDown, Receipt, Sparkles, CheckSquare, Calendar, StickyNote, Mail } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link, useLocation } from "wouter";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useSidebar } from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useState } from "react";

type MenuItem = {
  title: string;
  url?: string;
  icon: any;
  id: string;
  emoji?: string;
  iconColor?: string;
  subItems?: Array<{
    title: string;
    url: string;
    id: string;
    emoji?: string;
  }>;
};

// Icon color mapping based on reference design
const iconColorMap: Record<string, string> = {
  dashboard: "text-page-dashboard",
  projects: "text-page-projects",
  tasks: "text-green-600",
  reports: "text-page-tasks",
  statements: "text-page-projects",
  bitumen: "text-gray-700",
  sheets: "text-page-tasks",
  tenders: "text-page-tenders",
  alerts: "text-page-alerts",
  users: "text-page-users",
  roles: "text-gray-600",
  "ai-assistant": "text-purple-600",
  profile: "text-blue-600",
  messages: "text-orange-500",
  calendar: "text-blue-500",
  notes: "text-yellow-600",
  letters: "text-orange-600",
};

// Hover color mapping - deeper version of base colors
const hoverColorMap: Record<string, string> = {
  dashboard: "hover:bg-page-dashboard/10",
  projects: "hover:bg-page-projects/10",
  tasks: "hover:bg-green-600/10",
  reports: "hover:bg-page-tasks/10",
  statements: "hover:bg-page-projects/10",
  bitumen: "hover:bg-gray-700/10",
  sheets: "hover:bg-page-tasks/10",
  tenders: "hover:bg-page-tenders/10",
  alerts: "hover:bg-page-alerts/10",
  users: "hover:bg-page-users/10",
  roles: "hover:bg-gray-600/10",
  "ai-assistant": "hover:bg-purple-600/10",
  profile: "hover:bg-blue-600/10",
  messages: "hover:bg-orange-500/10",
  calendar: "hover:bg-blue-500/10",
  notes: "hover:bg-yellow-600/10",
  letters: "hover:bg-orange-600/10",
};

const menuItems: MenuItem[] = [
  { title: "داشبورد", url: "/", icon: Home, id: "dashboard" },
  { title: "وظایف", url: "/tasks", icon: CheckSquare, id: "tasks" },
  { title: "پروژه‌ها", url: "/projects", icon: FolderKanban, id: "projects" },
  { title: "تقویم", url: "/calendar", icon: Calendar, id: "calendar" },
  { title: "یادداشت‌ها", url: "/notes", icon: StickyNote, id: "notes" },
  { title: "نامه‌ها", url: "/letters", icon: Mail, id: "letters" },
  { 
    title: "گزارش روزانه", 
    icon: FileText, 
    id: "reports",
    subItems: [
      { title: "📑 دفتر فنی", url: "/reports/technical", id: "technical-report" },
      { title: "📋 اجرا", url: "/reports/execution", id: "execution-report" },
    ]
  },
  { title: "صورت‌وضعیت‌ها", url: "/statements", icon: Receipt, id: "statements" },
  { title: "قیر", url: "/bitumen", icon: Droplet, id: "bitumen" },
  { title: "شیت‌ها", url: "/sheets", icon: ClipboardList, id: "sheets" },
  { title: "مناقصات", url: "/tenders", icon: Gavel, id: "tenders" },
  { title: "هشدارها", url: "/alerts", icon: Bell, id: "alerts" },
];

const adminItems: MenuItem[] = [
  { title: "کاربران", url: "/users", icon: Users, id: "users" },
  { title: "نقش‌ها و مجوزها", url: "/roles", icon: Shield, id: "roles" },
];

const userItems: MenuItem[] = [
  { title: "دستیار هوش مصنوعی", url: "/ai-assistant", icon: Sparkles, id: "ai-assistant" },
  { title: "پروفایل من", url: "/profile", icon: UserIcon, id: "profile" },
  { title: "پیام‌ها", url: "/messages", icon: Inbox, id: "messages" },
];

export function AppSidebar({ currentUser }: { currentUser?: { name: string; role: string; avatar?: string } }) {
  const [location] = useLocation();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [openSubMenus, setOpenSubMenus] = useState<Set<string>>(new Set(["reports"]));

  const toggleSubMenu = (id: string) => {
    setOpenSubMenus(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const renderMenuItem = (item: MenuItem) => {
    const iconColor = iconColorMap[item.id] || "text-gray-600";
    const hoverColor = hoverColorMap[item.id] || "hover:bg-gray-100";
    
    if (item.subItems) {
      const hasActiveSubItem = item.subItems.some(subItem => location === subItem.url);
      const isOpen = openSubMenus.has(item.id);
      
      if (isCollapsed) {
        return (
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href={item.subItems[0].url}>
                <SidebarMenuButton data-testid={`nav-${item.id}`}>
                  <item.icon className={`w-5 h-5 ${iconColor}`} />
                </SidebarMenuButton>
              </Link>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{item.title}</p>
            </TooltipContent>
          </Tooltip>
        );
      }

      return (
        <Collapsible open={isOpen} onOpenChange={() => toggleSubMenu(item.id)}>
          <CollapsibleTrigger asChild>
            <SidebarMenuButton data-testid={`nav-${item.id}`} isActive={hasActiveSubItem} className={hoverColor}>
              <item.icon className={`w-5 h-5 ${iconColor}`} />
              <span>{item.title}</span>
              <ChevronDown className={`mr-auto w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </SidebarMenuButton>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <SidebarMenuSub>
              {item.subItems.map((subItem) => {
                const isActive = location === subItem.url;
                return (
                  <SidebarMenuSubItem key={subItem.id}>
                    <SidebarMenuSubButton asChild isActive={isActive}>
                      <Link href={subItem.url}>
                        <span>{subItem.title}</span>
                      </Link>
                    </SidebarMenuSubButton>
                  </SidebarMenuSubItem>
                );
              })}
            </SidebarMenuSub>
          </CollapsibleContent>
        </Collapsible>
      );
    }

    const isActive = location === item.url || (item.url !== "/" && location.startsWith(item.url!));
    
    const button = (
      <SidebarMenuButton asChild data-testid={`nav-${item.id}`} isActive={isActive} className={hoverColor}>
        <Link href={item.url!} className="flex items-center gap-3">
          <item.icon className={`w-5 h-5 ${iconColor}`} />
          {!isCollapsed && <span>{item.title}</span>}
        </Link>
      </SidebarMenuButton>
    );

    if (isCollapsed) {
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            {button}
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>{item.title}</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    return button;
  };

  return (
    <Sidebar side="left" collapsible="icon">
      <SidebarHeader className="p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
            س
          </div>
          {!isCollapsed && (
            <div className="flex-1">
              <h2 className="font-bold text-lg">سیستم مدیریت پروژه</h2>
              <p className="text-xs text-muted-foreground">سریع‌سازان البرز</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>منوی اصلی</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>مدیریت</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {adminItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>کاربری</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {userItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t">
        {!isCollapsed ? (
          <div className="flex items-center gap-3 p-2 rounded-md">
            <Avatar className="w-8 h-8">
              <AvatarImage src={currentUser?.avatar} />
              <AvatarFallback>
                <UserIcon className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{currentUser?.name || "کاربر"}</p>
              <p className="text-xs text-muted-foreground truncate">{currentUser?.role || "نقش"}</p>
            </div>
          </div>
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center justify-center p-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={currentUser?.avatar} />
                  <AvatarFallback>
                    <UserIcon className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
              </div>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{currentUser?.name || "کاربر"}</p>
              <p className="text-xs text-muted-foreground">{currentUser?.role || "نقش"}</p>
            </TooltipContent>
          </Tooltip>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
