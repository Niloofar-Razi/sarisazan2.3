import { PageHeader } from "./PageHeader";
import { Card } from "./ui/card";
import { useState } from "react";

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="تقویم"
        subtitle="مدیریت رویدادها و یادآورها"
        theme="calendar"
      />

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-6">
            <h3 className="text-lg font-semibold mb-4">تقویم ماهانه</h3>
            <div className="text-center text-muted-foreground py-12">
              تقویم جلالی در حال توسعه است
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">یادداشت روز</h3>
            <p className="text-sm text-muted-foreground">
              یک روز را انتخاب کنید تا یادداشت آن روز را مشاهده یا ویرایش کنید
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
