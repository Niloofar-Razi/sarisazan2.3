import { useState } from "react";
import { X, Edit, Check, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

export interface StickyNoteItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface StickyNoteProps {
  title: string;
  items: StickyNoteItem[];
  onItemToggle?: (id: string) => void;
  onItemEdit?: (id: string, newText: string) => void;
  onItemDelete?: (id: string) => void;
  onClose?: () => void;
  className?: string;
}

export function StickyNote({
  title,
  items,
  onItemToggle,
  onItemEdit,
  onItemDelete,
  onClose,
  className,
}: StickyNoteProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  const handleEdit = (item: StickyNoteItem) => {
    setEditingId(item.id);
    setEditText(item.text);
  };

  const handleSaveEdit = (id: string) => {
    if (onItemEdit && editText.trim()) {
      onItemEdit(id, editText);
    }
    setEditingId(null);
    setEditText("");
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditText("");
  };

  return (
    <div
      className={cn(
        "relative rounded-lg shadow-lg p-4 min-w-[250px] max-w-[350px]",
        "bg-sticky-note text-sticky-note-foreground",
        className
      )}
    >
      {/* Header with title and close button */}
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/20">
        <h3 className="font-semibold text-sm">{title}</h3>
        {onClose && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-6 w-6 hover:bg-white/20 text-sticky-note-foreground"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Checklist items */}
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.id} className="flex items-start gap-2 group">
            <Checkbox
              checked={item.completed}
              onCheckedChange={() => onItemToggle?.(item.id)}
              className="mt-0.5 border-white/40 data-[state=checked]:bg-white data-[state=checked]:text-sticky-note"
            />
            
            {editingId === item.id ? (
              <div className="flex-1 flex items-center gap-1">
                <input
                  type="text"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSaveEdit(item.id);
                    if (e.key === "Escape") handleCancelEdit();
                  }}
                  className="flex-1 bg-white/20 border border-white/40 rounded px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-white/50"
                  autoFocus
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleSaveEdit(item.id)}
                  className="h-6 w-6 hover:bg-white/20"
                >
                  <Check className="h-3 w-3" />
                </Button>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-between">
                <span
                  className={cn(
                    "text-sm",
                    item.completed && "line-through opacity-70"
                  )}
                >
                  {item.text}
                </span>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                  {onItemEdit && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(item)}
                      className="h-6 w-6 hover:bg-white/20"
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                  )}
                  {onItemDelete && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onItemDelete(item.id)}
                      className="h-6 w-6 hover:bg-white/20"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Action buttons at bottom */}
      <div className="mt-4 pt-3 border-t border-white/20 flex justify-between">
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-white/20"
            title="حذف"
          >
            <X className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-white/20"
            title="کپی"
          >
            <Check className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-white/20"
            title="ویرایش"
          >
            <Edit className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
