import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Search, UserPlus, Edit, Trash2, Mail, Phone, Briefcase } from "lucide-react";

interface User {
  id: string;
  username: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  role: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt?: Date;
}

interface Project {
  id: string;
  title: string;
  status: string;
}

interface UserProjectAssignment {
  id: string;
  userId: string;
  projectId: string;
  assignedAt: Date;
  projectTitle: string;
  projectLocation?: string;
  projectStatus: string;
}

export default function UsersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isProjectsDialogOpen, setIsProjectsDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users", { search: searchTerm, role: roleFilter !== "all" ? roleFilter : undefined, isActive: statusFilter !== "all" ? statusFilter : undefined }],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: userProjects = [] } = useQuery<UserProjectAssignment[]>({
    queryKey: [`/api/users/${selectedUser?.id}/projects`],
    enabled: !!selectedUser && isProjectsDialogOpen,
  });

  const addUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      });
      if (!res.ok) throw new Error("خطا در افزودن کاربر");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsAddDialogOpen(false);
      toast({ title: "موفق", description: "کاربر با موفقیت اضافه شد" });
    },
  });

  const editUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await fetch(`/api/users/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("خطا در ویرایش کاربر");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsEditDialogOpen(false);
      toast({ title: "موفق", description: "کاربر با موفقیت ویرایش شد" });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/users/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا در حذف کاربر");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "موفق", description: "کاربر با موفقیت حذف شد" });
    },
  });

  const assignProjectMutation = useMutation({
    mutationFn: async ({ userId, projectId }: { userId: string; projectId: string }) => {
      const res = await fetch(`/api/users/${userId}/projects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId }),
      });
      if (!res.ok) throw new Error("خطا در تخصیص پروژه");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${selectedUser?.id}/projects`] });
      toast({ title: "موفق", description: "پروژه با موفقیت تخصیص داده شد" });
    },
  });

  const unassignProjectMutation = useMutation({
    mutationFn: async ({ userId, projectId }: { userId: string; projectId: string }) => {
      const res = await fetch(`/api/users/${userId}/projects/${projectId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("خطا در حذف تخصیص پروژه");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${selectedUser?.id}/projects`] });
      toast({ title: "موفق", description: "تخصیص پروژه حذف شد" });
    },
  });

  const handleAddUser = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    addUserMutation.mutate({
      username: formData.get("username"),
      password: formData.get("password"),
      firstName: formData.get("firstName"),
      lastName: formData.get("lastName"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      role: formData.get("role"),
      isActive: true,
    });
  };

  const handleEditUser = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedUser) return;
    const formData = new FormData(e.currentTarget);
    const data: any = {
      firstName: formData.get("firstName"),
      lastName: formData.get("lastName"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      role: formData.get("role"),
      isActive: formData.get("isActive") === "true",
    };
    const password = formData.get("password") as string;
    if (password) data.password = password;
    editUserMutation.mutate({ id: selectedUser.id, data });
  };

  const getFullName = (user: User) => {
    if (user.firstName || user.lastName) {
      return `${user.firstName || ""} ${user.lastName || ""}`.trim();
    }
    return user.username;
  };

  const getRoleLabel = (role: string) => {
    const roles: Record<string, string> = {
      admin: "مدیر سیستم",
      project_manager: "مدیر پروژه",
      engineer: "مهندس",
      supervisor: "سرپرست",
      user: "کاربر عادی",
    };
    return roles[role] || role;
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">مدیریت کاربران</h1>
        <p className="text-muted-foreground">لیست و مدیریت کاربران سیستم</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>جستجو و فیلتر</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو (نام، نام کاربری، ایمیل)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-9"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="نقش" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه نقش‌ها</SelectItem>
                <SelectItem value="admin">مدیر سیستم</SelectItem>
                <SelectItem value="project_manager">مدیر پروژه</SelectItem>
                <SelectItem value="engineer">مهندس</SelectItem>
                <SelectItem value="supervisor">سرپرست</SelectItem>
                <SelectItem value="user">کاربر عادی</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="true">فعال</SelectItem>
                <SelectItem value="false">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between items-center mb-6">
        <div className="text-sm text-muted-foreground">
          تعداد کاربران: {users.length}
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="ml-2 h-4 w-4" />
              افزودن کاربر جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <form onSubmit={handleAddUser}>
              <DialogHeader>
                <DialogTitle>افزودن کاربر جدید</DialogTitle>
                <DialogDescription>
                  اطلاعات کاربر جدید را وارد کنید
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div>
                  <Label htmlFor="username">نام کاربری *</Label>
                  <Input id="username" name="username" required />
                </div>
                <div>
                  <Label htmlFor="password">رمز عبور *</Label>
                  <Input id="password" name="password" type="password" required />
                </div>
                <div>
                  <Label htmlFor="firstName">نام</Label>
                  <Input id="firstName" name="firstName" />
                </div>
                <div>
                  <Label htmlFor="lastName">نام خانوادگی</Label>
                  <Input id="lastName" name="lastName" />
                </div>
                <div>
                  <Label htmlFor="email">ایمیل</Label>
                  <Input id="email" name="email" type="email" />
                </div>
                <div>
                  <Label htmlFor="phone">تلفن</Label>
                  <Input id="phone" name="phone" />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="role">نقش</Label>
                  <Select name="role" defaultValue="user">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">کاربر عادی</SelectItem>
                      <SelectItem value="supervisor">سرپرست</SelectItem>
                      <SelectItem value="engineer">مهندس</SelectItem>
                      <SelectItem value="project_manager">مدیر پروژه</SelectItem>
                      <SelectItem value="admin">مدیر سیستم</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={addUserMutation.isPending}>
                  {addUserMutation.isPending ? "در حال افزودن..." : "افزودن کاربر"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="text-center py-12">در حال بارگذاری...</div>
      ) : users.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            کاربری یافت نشد
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.map((user) => (
            <Card key={user.id} className="hover-elevate">
              <CardContent className="p-6">
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="text-lg">
                      {(user.firstName?.[0] || user.username[0]).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="font-bold truncate">{getFullName(user)}</h3>
                      <Badge variant={user.isActive ? "default" : "secondary"}>
                        {user.isActive ? "فعال" : "غیرفعال"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">@{user.username}</p>
                    <Badge variant="outline" className="mb-3">
                      <Briefcase className="w-3 h-3 ml-1" />
                      {getRoleLabel(user.role)}
                    </Badge>
                  </div>
                </div>

                {(user.email || user.phone) && (
                  <div className="space-y-1 mb-4 text-sm">
                    {user.email && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Mail className="w-4 h-4" />
                        <span className="truncate">{user.email}</span>
                      </div>
                    )}
                    {user.phone && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Phone className="w-4 h-4" />
                        <span>{user.phone}</span>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => {
                      setSelectedUser(user);
                      setIsProjectsDialogOpen(true);
                    }}
                  >
                    پروژه‌ها
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedUser(user);
                      setIsEditDialogOpen(true);
                    }}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (confirm("آیا از حذف این کاربر اطمینان دارید؟")) {
                        deleteUserMutation.mutate(user.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <form onSubmit={handleEditUser}>
            <DialogHeader>
              <DialogTitle>ویرایش کاربر</DialogTitle>
              <DialogDescription>
                اطلاعات کاربر {selectedUser?.username} را ویرایش کنید
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div>
                <Label htmlFor="edit-firstName">نام</Label>
                <Input
                  id="edit-firstName"
                  name="firstName"
                  defaultValue={selectedUser?.firstName || ""}
                />
              </div>
              <div>
                <Label htmlFor="edit-lastName">نام خانوادگی</Label>
                <Input
                  id="edit-lastName"
                  name="lastName"
                  defaultValue={selectedUser?.lastName || ""}
                />
              </div>
              <div>
                <Label htmlFor="edit-email">ایمیل</Label>
                <Input
                  id="edit-email"
                  name="email"
                  type="email"
                  defaultValue={selectedUser?.email || ""}
                />
              </div>
              <div>
                <Label htmlFor="edit-phone">تلفن</Label>
                <Input
                  id="edit-phone"
                  name="phone"
                  defaultValue={selectedUser?.phone || ""}
                />
              </div>
              <div>
                <Label htmlFor="edit-role">نقش</Label>
                <Select name="role" defaultValue={selectedUser?.role}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">کاربر عادی</SelectItem>
                    <SelectItem value="supervisor">سرپرست</SelectItem>
                    <SelectItem value="engineer">مهندس</SelectItem>
                    <SelectItem value="project_manager">مدیر پروژه</SelectItem>
                    <SelectItem value="admin">مدیر سیستم</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="edit-isActive">وضعیت</Label>
                <Select name="isActive" defaultValue={selectedUser?.isActive ? "true" : "false"}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="true">فعال</SelectItem>
                    <SelectItem value="false">غیرفعال</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label htmlFor="edit-password">رمز عبور جدید (اختیاری)</Label>
                <Input
                  id="edit-password"
                  name="password"
                  type="password"
                  placeholder="برای تغییر رمز عبور وارد کنید"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" disabled={editUserMutation.isPending}>
                {editUserMutation.isPending ? "در حال ویرایش..." : "ذخیره تغییرات"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* User Projects Dialog */}
      <Dialog open={isProjectsDialogOpen} onOpenChange={setIsProjectsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>پروژه‌های {selectedUser && getFullName(selectedUser)}</DialogTitle>
            <DialogDescription>
              مدیریت پروژه‌های تخصیص داده شده به این کاربر
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="mb-4">
              <Label>افزودن پروژه جدید</Label>
              <div className="flex gap-2 mt-2">
                <Select
                  onValueChange={(projectId) => {
                    if (selectedUser) {
                      assignProjectMutation.mutate({ userId: selectedUser.id, projectId });
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="انتخاب پروژه..." />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>پروژه‌های فعلی</Label>
              <div className="mt-2 space-y-2">
                {userProjects.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">
                    هیچ پروژه‌ای تخصیص داده نشده است
                  </p>
                ) : (
                  userProjects.map((up: any) => (
                    <Card key={up.id}>
                      <CardContent className="p-3 flex items-center justify-between">
                        <div>
                          <p className="font-medium">{up.projectTitle}</p>
                          <p className="text-sm text-muted-foreground">{up.projectLocation}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (selectedUser) {
                              unassignProjectMutation.mutate({
                                userId: selectedUser.id,
                                projectId: up.projectId,
                              });
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
