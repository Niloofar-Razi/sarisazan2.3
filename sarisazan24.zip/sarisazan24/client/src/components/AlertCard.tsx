import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, Info, AlertTriangle, CheckCircle2 } from "lucide-react";

interface AlertCardProps {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  project?: string;
  date: string;
  isRead: boolean;
  onMarkRead?: (id: string) => void;
}

const alertConfig = {
  info: {
    icon: Info,
    variant: "default" as const,
    bgClass: "bg-blue-500/20",
    borderClass: "border-l-4 border-l-blue-500",
    iconColor: "text-blue-600",
    badgeClass: "bg-blue-100 text-blue-700 border-blue-300",
  },
  warning: {
    icon: AlertTriangle,
    variant: "outline" as const,
    bgClass: "bg-yellow-500/20",
    borderClass: "border-l-4 border-l-yellow-500",
    iconColor: "text-yellow-600",
    badgeClass: "bg-yellow-100 text-yellow-700 border-yellow-300",
  },
  error: {
    icon: AlertCircle,
    variant: "destructive" as const,
    bgClass: "bg-red-500/20",
    borderClass: "border-l-4 border-l-red-500",
    iconColor: "text-red-600",
    badgeClass: "bg-red-100 text-red-700 border-red-300",
  },
  success: {
    icon: CheckCircle2,
    variant: "secondary" as const,
    bgClass: "bg-green-500/20",
    borderClass: "border-l-4 border-l-green-500",
    iconColor: "text-green-600",
    badgeClass: "bg-green-100 text-green-700 border-green-300",
  },
};

export default function AlertCard({ id, title, message, type, project, date, isRead, onMarkRead }: AlertCardProps) {
  const config = alertConfig[type];
  const Icon = config.icon;

  return (
    <Card className={`hover-elevate transition-all ${config.borderClass} ${!isRead ? 'shadow-md' : ''}`}>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <div className={`p-2 rounded-md h-fit ${config.bgClass}`}>
            <Icon className={`w-5 h-5 ${config.iconColor}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h4 className="font-bold truncate" data-testid={`alert-title-${id}`}>{title}</h4>
              <Badge variant="outline" className={`shrink-0 ${config.badgeClass}`}>
                {type === "info" && "اطلاع"}
                {type === "warning" && "هشدار"}
                {type === "error" && "فوری"}
                {type === "success" && "موفق"}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{message}</p>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                {project && <span>پروژه: {project}</span>}
                <span>{date}</span>
              </div>
              {!isRead && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onMarkRead?.(id)}
                  data-testid={`button-mark-read-${id}`}
                  className="text-xs"
                >
                  خوانده شد ✓
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
