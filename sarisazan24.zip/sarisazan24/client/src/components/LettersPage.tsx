import { PageHeader } from "./PageHeader";
import { Button } from "./ui/button";
import { Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Inbox, Send, FolderOpen } from "lucide-react";

export default function LettersPage() {
  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="نامه‌ها"
        subtitle="مدیریت نامه‌ها و پیام‌های اداری"
        theme="letters"
        actions={
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            <span>نامه جدید</span>
          </Button>
        }
      />

      <div className="container mx-auto p-6">
        <Tabs defaultValue="inbox" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="inbox" className="gap-2">
              <Inbox className="w-4 h-4" />
              صندوق ورودی
            </TabsTrigger>
            <TabsTrigger value="sent" className="gap-2">
              <Send className="w-4 h-4" />
              صندوق خروجی
            </TabsTrigger>
            <TabsTrigger value="project" className="gap-2">
              <FolderOpen className="w-4 h-4" />
              صندوق پروژه
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inbox" className="mt-6">
            <div className="space-y-3">
              <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold">عنوان نامه نمونه</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      متن خلاصه نامه...
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline">از: کاربر نمونه</Badge>
                      <Badge>جدید</Badge>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sent" className="mt-6">
            <p className="text-center text-muted-foreground py-8">
              صندوق خروجی خالی است
            </p>
          </TabsContent>

          <TabsContent value="project" className="mt-6">
            <p className="text-center text-muted-foreground py-8">
              ابتدا یک پروژه انتخاب کنید
            </p>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
