import { PageHeader } from "./PageHeader";
import { Button } from "./ui/button";
import { Plus } from "lucide-react";
import { Card } from "./ui/card";
import { Checkbox } from "./ui/checkbox";

const stickyColors = [
  { name: "زرد", value: "bg-yellow-100 border-yellow-300" },
  { name: "سبز", value: "bg-green-100 border-green-300" },
  { name: "آبی", value: "bg-blue-100 border-blue-300" },
  { name: "صورتی", value: "bg-pink-100 border-pink-300" },
];

export default function NotesPage() {
  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="یادداشت‌های من"
        subtitle="یادداشت‌های چسبان رنگی"
        theme="notes"
        actions={
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            <span>یادداشت جدید</span>
          </Button>
        }
      />

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {stickyColors.map((color, idx) => (
            <Card
              key={idx}
              className={`p-4 border-2 ${color.value} hover:shadow-lg transition-shadow`}
            >
              <h3 className="font-bold text-lg mb-3">یادداشت نمونه {color.name}</h3>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Checkbox className="mt-1" />
                  <span className="text-sm">مورد اول</span>
                </div>
                <div className="flex items-start gap-2">
                  <Checkbox className="mt-1" />
                  <span className="text-sm">مورد دوم</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
