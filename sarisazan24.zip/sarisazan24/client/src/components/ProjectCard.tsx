import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, DollarSign, MapPin, ArrowLeft, ListTodo } from "lucide-react";
import { useState, useEffect } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface ProjectCardProps {
  id: string;
  title: string;
  contractNumber: string | null;
  location: string | null;
  employer: string | null;
  amount: string | null;
  progress: number | null;
  status: string | null;
  startDate: string | null;
  onViewDetails?: (id: string) => void;
}

interface TaskStats {
  total: number;
  completed: number;
  pending: number;
}

const statusLabels: Record<string, string> = {
  active: "در حال اجرا",
  completed: "تکمیل شده",
  pending: "در انتظار",
  suspended: "متوقف شده",
};

const statusVariants: Record<string, "default" | "outline" | "destructive"> = {
  active: "default" as const,
  completed: "default" as const,
  pending: "outline" as const,
  suspended: "destructive" as const,
};

export default function ProjectCard({
  id,
  title,
  contractNumber,
  location,
  employer,
  amount,
  progress,
  status,
  startDate,
  onViewDetails,
}: ProjectCardProps) {
  const [taskStats, setTaskStats] = useState<TaskStats | null>(null);
  const [loadingTasks, setLoadingTasks] = useState(false);

  const fetchProjectTasks = async () => {
    setLoadingTasks(true);
    try {
      const response = await fetch(`/api/tasks/by-project/${id}`);
      if (response.ok) {
        const data = await response.json();
        setTaskStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching project tasks:', error);
    } finally {
      setLoadingTasks(false);
    }
  };

  const completionPercentage = taskStats && taskStats.total > 0
    ? Math.round((taskStats.completed / taskStats.total) * 100)
    : 0;

  return (
    <Card className="hover-elevate transition-all">
      <CardHeader className="gap-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg truncate" data-testid={`project-title-${id}`}>{title}</h3>
            <p className="text-sm text-muted-foreground">شماره قرارداد: {contractNumber || "نامشخص"}</p>
          </div>
          <div className="flex gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="gap-1"
                  onClick={fetchProjectTasks}
                >
                  <ListTodo className="w-4 h-4" />
                  وظایف
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                {loadingTasks ? (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    در حال بارگذاری...
                  </div>
                ) : taskStats ? (
                  <div className="space-y-4">
                    <div className="text-sm font-medium">مهم‌ترین وظیفه‌های این پروژه</div>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>کل وظایف</span>
                        <Badge variant="outline">{taskStats.total}</Badge>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-green-600">انجام شده</span>
                          <span className="text-green-600 font-medium">{taskStats.completed}</span>
                        </div>
                        <Progress value={taskStats.total > 0 ? (taskStats.completed / taskStats.total) * 100 : 0} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-orange-600">در انتظار</span>
                          <span className="text-orange-600 font-medium">{taskStats.pending}</span>
                        </div>
                        <Progress value={taskStats.total > 0 ? (taskStats.pending / taskStats.total) * 100 : 0} className="h-2" />
                      </div>

                      <div className="pt-2 border-t">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium">درصد تکمیل</span>
                          <span className="font-bold text-primary">{completionPercentage}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    وظیفه‌ای برای این پروژه وجود ندارد
                  </div>
                )}
              </PopoverContent>
            </Popover>
            <Badge variant={statusVariants[status || "active"]} data-testid={`project-status-${id}`}>
              {statusLabels[status || "active"]}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {location && (
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span>{location}</span>
            </div>
          )}
          {amount && (
            <div className="flex items-center gap-2 text-sm">
              <DollarSign className="w-4 h-4 text-muted-foreground" />
              <span>{amount} ریال</span>
            </div>
          )}
          {startDate && (
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span>شروع: {startDate}</span>
            </div>
          )}
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">پیشرفت ریالی</span>
            <span className="font-medium">{progress ?? 0}%</span>
          </div>
          <Progress value={progress ?? 0} className="h-2" />
        </div>
        {employer && <p className="text-sm text-muted-foreground">کارفرما: {employer}</p>}
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={() => onViewDetails?.(id)}
          data-testid={`button-view-project-${id}`}
        >
          مشاهده جزئیات
          <ArrowLeft className="w-4 h-4 mr-2" />
        </Button>
      </CardFooter>
    </Card>
  );
}
