import { db } from "./db";
import { projects, alerts, tenders, statements } from "@shared/schema";
import { eq, or, like, sql as sqlOperator } from "drizzle-orm";

interface AssistantContext {
  projects: any[];
  alerts: any[];
  tenders: any[];
  statements: any[];
}

async function getProjectContext(projectId?: string): Promise<AssistantContext> {
  const context: AssistantContext = {
    projects: [],
    alerts: [],
    tenders: [],
    statements: []
  };

  if (projectId) {
    const project = await db.select().from(projects).where(eq(projects.id, projectId));
    context.projects = project;
    
    const projectAlerts = await db.select().from(alerts).where(eq(alerts.projectId, projectId));
    context.alerts = projectAlerts;

    const allTenders = await db.select().from(tenders);
    context.tenders = allTenders;

    const projectStatements = await db.select().from(statements).where(eq(statements.projectId, projectId));
    context.statements = projectStatements;
  } else {
    context.projects = await db.select().from(projects);
    context.alerts = await db.select().from(alerts);
    context.tenders = await db.select().from(tenders);
    context.statements = await db.select().from(statements);
  }

  return context;
}

// تابع کمکی برای حذف نویسه‌های خاص فارسی (نیم‌فاصله و ZWNJ)
function cleanPersianText(text: string): string {
  return text
    .replace(/\u200C/g, '') // حذف ZWNJ (Zero-Width Non-Joiner)
    .replace(/\u200B/g, '') // حذف Zero-Width Space
    .replace(/\u200D/g, '') // حذف Zero-Width Joiner
    .replace(/\s+/g, ' ')   // یکسان‌سازی فاصله‌ها
    .toLowerCase()
    .trim();
}

// تابع کمکی برای تبدیل اعداد فارسی به انگلیسی
function convertPersianDigits(text: string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  
  let result = text;
  persianDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, 'g'), index.toString());
  });
  arabicDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, 'g'), index.toString());
  });
  
  return result;
}

// تابع کمکی برای تشخیص کلمات کلیدی در متن فارسی
function containsKeywords(text: string, keywords: string[]): boolean {
  const cleanedText = cleanPersianText(text);
  return keywords.some(keyword => cleanedText.includes(cleanPersianText(keyword)));
}

// تابع کمکی برای نرمال‌سازی متن فارسی
function normalizeText(text: string): string[] {
  return cleanPersianText(text)
    .replace(/[؟!,،.\?\:\;«»\(\)]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 1)
    .filter(word => !['در', 'به', 'از', 'با', 'که', 'این', 'آن', 'و', 'یا', 'را', 'های'].includes(word));
}

// تابع کمکی برای جستجوی پروژه‌ها بر اساس تطابق توکن
function searchProjects(query: string, projects: any[]): any[] {
  const queryTokens = normalizeText(query);
  
  return projects.filter(p => {
    const titleTokens = normalizeText(p.title || '');
    const contractTokens = normalizeText(p.contractNumber || '');
    const locationTokens = normalizeText(p.location || '');
    const contractorTokens = normalizeText(p.contractor || '');
    
    const hasCommonWithTitle = queryTokens.some(qt => titleTokens.some(tt => tt.includes(qt) || qt.includes(tt)));
    const hasCommonWithContract = queryTokens.some(qt => contractTokens.some(ct => ct.includes(qt) || qt.includes(ct)));
    const hasCommonWithLocation = queryTokens.some(qt => locationTokens.some(lt => lt.includes(qt) || qt.includes(lt)));
    const hasCommonWithContractor = queryTokens.some(qt => contractorTokens.some(ct => ct.includes(qt) || qt.includes(ct)));
    
    return hasCommonWithTitle || hasCommonWithContract || hasCommonWithLocation || hasCommonWithContractor;
  });
}

// تابع کمکی برای استخراج مبلغ از رشته
function parseAmount(amountStr: string): number {
  if (!amountStr) return 0;
  const cleaned = amountStr.replace(/[,،\s]/g, '').replace(/ریال/g, '');
  return parseInt(cleaned) || 0;
}

// تابع کمکی برای فرمت کردن عدد به فارسی
function formatNumber(num: number): string {
  return num.toLocaleString('fa-IR');
}

// تابع اصلی دستیار هوش مصنوعی
export async function chatWithAssistant(message: string, projectId?: string): Promise<string> {
  try {
    const context = await getProjectContext(projectId);
    const lowerMessage = message.toLowerCase();

    // پاسخ به سوالات مربوط به شماره قرارداد
    if (containsKeywords(lowerMessage, ['شماره قرارداد', 'شماره پروژه', 'کد قرارداد'])) {
      const foundProjects = searchProjects(message, context.projects);
      
      if (foundProjects.length > 0) {
        const project = foundProjects[0];
        return `📋 **شماره قرارداد پروژه "${project.title}":**\n\n• شماره: ${project.contractNumber || 'ثبت نشده'}\n• تاریخ: ${project.contractDate || 'ثبت نشده'}\n• پیمانکار: ${project.contractor || 'ثبت نشده'}`;
      }
      return 'در حال حاضر اطلاعاتی برای این مورد ثبت نشده است.';
    }

    // پاسخ به سوالات مربوط به پیمانکار
    if (containsKeywords(lowerMessage, ['پیمانکار', 'contractor', 'کیست', 'کدام شرکت'])) {
      const foundProjects = searchProjects(message, context.projects);
      
      if (foundProjects.length > 0) {
        const project = foundProjects[0];
        return `🏢 **پیمانکار پروژه "${project.title}":**\n\n• پیمانکار: ${project.contractor || 'ثبت نشده'}\n• کارفرما: ${project.employer || 'ثبت نشده'}\n• شماره قرارداد: ${project.contractNumber || 'ثبت نشده'}`;
      }
      return 'در حال حاضر اطلاعاتی برای این مورد ثبت نشده است.';
    }

    // پاسخ به سوالات مربوط به درصد پیشرفت پیمانکار خاص
    if ((containsKeywords(lowerMessage, ['پیشرفت', 'درصد']) || containsKeywords(lowerMessage, ['اعلام کن', 'نشان بده'])) && 
        (containsKeywords(lowerMessage, ['سریع سازان', 'سریعسازان', 'البرز']) || 
         containsKeywords(lowerMessage, ['بهینه مطبوع', 'کاوش کار', 'بهینه', 'مطبوع']) ||
         containsKeywords(lowerMessage, ['خاک پی دنا', 'دنا']) ||
         containsKeywords(lowerMessage, ['سازندگی', 'الماس ساز', 'اطلس']))) {
      
      let contractorName = '';
      if (containsKeywords(lowerMessage, ['سریع سازان', 'سریعسازان', 'البرز'])) {
        contractorName = 'سریع سازان البرز';
      } else if (containsKeywords(lowerMessage, ['بهینه مطبوع', 'کاوش کار', 'بهینه', 'مطبوع'])) {
        contractorName = 'بهینه مطبوع کاوش کار';
      } else if (containsKeywords(lowerMessage, ['خاک پی دنا', 'دنا'])) {
        contractorName = 'خاک پی دنا';
      } else if (containsKeywords(lowerMessage, ['سازندگی', 'الماس ساز', 'اطلس'])) {
        contractorName = 'سازندگی الماس ساز اطلس';
      }

      const contractorProjects = context.projects.filter(p => 
        p.contractor && p.contractor.includes(contractorName)
      );

      if (contractorProjects.length > 0) {
        let response = `📊 **پیشرفت پروژه‌های ${contractorName}:**\n\n`;
        contractorProjects.forEach((p, i) => {
          response += `${i + 1}. ${p.title}\n   • پیشرفت: ${p.progress || 0}%\n\n`;
        });
        
        const avgProgress = contractorProjects.reduce((sum, p) => sum + (p.progress || 0), 0) / contractorProjects.length;
        response += `📈 **میانگین پیشرفت:** ${avgProgress.toFixed(1)}%`;
        return response;
      }
      return 'در حال حاضر اطلاعاتی برای این پیمانکار ثبت نشده است.';
    }

    // پاسخ به سوالات مربوط به مجموع مبلغ قراردادها (بر اساس سال)
    if (containsKeywords(lowerMessage, ['مجموع', 'جمع', 'total']) && 
        containsKeywords(lowerMessage, ['مبلغ', 'قرارداد', 'amount'])) {
      
      const convertedForYear = convertPersianDigits(lowerMessage);
      let yearMatch = convertedForYear.match(/\d{4}/);
      if (yearMatch) {
        const year = yearMatch[0];
        const yearProjects = context.projects.filter(p => 
          p.contractDate && p.contractDate.includes(year)
        );

        if (yearProjects.length > 0) {
          const total = yearProjects.reduce((sum, p) => sum + parseAmount(p.amount || ''), 0);
          return `💰 **مجموع مبلغ قراردادهای سال ${year}:**\n\n• تعداد: ${yearProjects.length} قرارداد\n• مجموع: ${formatNumber(total)} ریال\n• میانگین: ${formatNumber(Math.floor(total / yearProjects.length))} ریال`;
        }
        return `در حال حاضر قراردادی برای سال ${year} ثبت نشده است.`;
      }
      
      // اگر سالی مشخص نشده، کل قراردادها
      const total = context.projects.reduce((sum, p) => sum + parseAmount(p.amount || ''), 0);
      return `💰 **مجموع کل قراردادها:**\n\n• تعداد: ${context.projects.length} قرارداد\n• مجموع: ${formatNumber(total)} ریال`;
    }

    // پاسخ به سوالات مربوط به پروژه‌های بالای یا پایین درصد خاص
    const convertedMessage = convertPersianDigits(lowerMessage);
    const percentMatch = convertedMessage.match(/(\d+)\s*%|(\d+)\s*درصد/);
    if (percentMatch && (containsKeywords(lowerMessage, ['بیش از', 'بالای', 'above', 'بیشتر']) || 
        containsKeywords(lowerMessage, ['کمتر از', 'زیر', 'پایین']))) {
      
      const threshold = parseInt(percentMatch[1] || percentMatch[2]);
      const isAbove = containsKeywords(lowerMessage, ['بیش از', 'بالای', 'above', 'بیشتر']);
      
      const filteredProjects = context.projects.filter(p => 
        isAbove ? (p.progress || 0) > threshold : (p.progress || 0) < threshold
      );

      if (filteredProjects.length > 0) {
        let response = `📊 **پروژه‌های ${isAbove ? 'بیش از' : 'کمتر از'} ${threshold}% پیشرفت:**\n\n`;
        filteredProjects.slice(0, 10).forEach((p, i) => {
          response += `${i + 1}. ${p.title}\n   • پیشرفت: ${p.progress || 0}%\n   • پیمانکار: ${p.contractor || 'ندارد'}\n\n`;
        });
        
        if (filteredProjects.length > 10) {
          response += `\n... و ${filteredProjects.length - 10} پروژه دیگر`;
        }
        return response;
      }
      return `پروژه‌ای با پیشرفت ${isAbove ? 'بیش از' : 'کمتر از'} ${threshold}% یافت نشد.`;
    }

    // پاسخ به سوالات مربوط به کارفرما
    if (containsKeywords(lowerMessage, ['کارفرما', 'employer', 'راهداری', 'فهرست پروژه'])) {
      let employerName = '';
      
      if (containsKeywords(lowerMessage, ['راهداری قزوین', 'راهداری'])) {
        employerName = 'راهداری قزوین';
      } else if (containsKeywords(lowerMessage, ['راه و شهرسازی', 'شهرسازی'])) {
        employerName = 'راه و شهرسازی';
      } else if (containsKeywords(lowerMessage, ['نوسازی مدارس'])) {
        employerName = 'نوسازی مدارس';
      }

      if (employerName) {
        const employerProjects = context.projects.filter(p => 
          p.employer && p.employer.includes(employerName)
        );

        if (employerProjects.length > 0) {
          let response = `📋 **فهرست پروژه‌های ${employerName}:**\n\n`;
          employerProjects.slice(0, 10).forEach((p, i) => {
            response += `${i + 1}. ${p.title}\n   • قرارداد: ${p.contractNumber || 'ندارد'}\n   • پیشرفت: ${p.progress || 0}%\n\n`;
          });
          
          if (employerProjects.length > 10) {
            response += `\n... و ${employerProjects.length - 10} پروژه دیگر`;
          }
          
          const total = employerProjects.reduce((sum, p) => sum + parseAmount(p.amount || ''), 0);
          response += `\n💰 مجموع مبلغ: ${formatNumber(total)} ریال`;
          return response;
        }
      }
    }

    // پاسخ به سوالات مربوط به تعداد پروژه‌ها
    if (containsKeywords(lowerMessage, ['چند پروژه', 'تعداد پروژه', 'چندتا پروژه', 'چقدر پروژه'])) {
      const totalProjects = context.projects.length;
      const activeProjects = context.projects.filter(p => p.status === 'active').length;
      const completedProjects = context.projects.filter(p => p.status === 'completed').length;
      
      return `📊 **اطلاعات پروژه‌ها:**
      
• مجموع پروژه‌ها: ${totalProjects} پروژه
• پروژه‌های فعال: ${activeProjects} پروژه
• پروژه‌های تکمیل شده: ${completedProjects} پروژه
• پروژه‌های در حال برنامه‌ریزی: ${context.projects.filter(p => p.status === 'planning').length} پروژه`;
    }

    // پاسخ به سوالات مربوط به هشدارها
    if (containsKeywords(lowerMessage, ['هشدار', 'اخطار', 'alert', 'چند هشدار', 'تعداد هشدار'])) {
      const openAlerts = context.alerts.filter(a => a.status === 'open');
      const criticalAlerts = openAlerts.filter(a => a.severity === 'critical');
      const warningAlerts = openAlerts.filter(a => a.severity === 'warning');
      
      if (openAlerts.length === 0) {
        return '✅ هیچ هشدار بازی در سیستم وجود ندارد.';
      }
      
      let response = `🔔 **هشدارهای باز:**\n\n• مجموع هشدارها: ${openAlerts.length}\n`;
      
      if (criticalAlerts.length > 0) {
        response += `• هشدارهای بحرانی: ${criticalAlerts.length}\n`;
      }
      if (warningAlerts.length > 0) {
        response += `• هشدارهای هشدار: ${warningAlerts.length}\n`;
      }
      
      response += '\n**آخرین هشدارها:**\n';
      openAlerts.slice(0, 3).forEach((alert, i) => {
        response += `\n${i + 1}. ${alert.title} (${alert.severity === 'critical' ? '🔴 بحرانی' : alert.severity === 'warning' ? '🟡 هشدار' : '🔵 اطلاعات'})`;
      });
      
      return response;
    }

    // پاسخ به سوالات مربوط به مناقصه‌ها
    if (containsKeywords(lowerMessage, ['مناقصه', 'tender', 'چند مناقصه', 'تعداد مناقصه', 'ددلاین', 'deadline'])) {
      const totalTenders = context.tenders.length;
      const openTenders = context.tenders.filter(t => t.status === 'open').length;
      
      return `📋 **اطلاعات مناقصه‌ها:**
      
• مجموع مناقصه‌ها: ${totalTenders}
• مناقصه‌های باز: ${openTenders}
• مناقصه‌های بسته: ${context.tenders.filter(t => t.status === 'closed').length}`;
    }

    // پاسخ به سوالات مربوط به صورت‌وضعیت‌ها
    if (containsKeywords(lowerMessage, ['صورت وضعیت', 'صورت‌وضعیت', 'وضعیت', 'statement'])) {
      const totalStatements = context.statements.length;
      const approvedStatements = context.statements.filter(s => s.status === 'تأیید شده').length;
      
      return `📝 **اطلاعات صورت‌وضعیت‌ها:**
      
• مجموع صورت‌وضعیت‌ها: ${totalStatements}
• تأیید شده: ${approvedStatements}
• در انتظار: ${context.statements.filter(s => s.status === 'در انتظار').length}`;
    }

    // جستجوی پروژه بر اساس نام یا شماره قرارداد
    if (containsKeywords(lowerMessage, ['پروژه', 'قرارداد', 'project'])) {
      const foundProjects = searchProjects(message, context.projects);
      
      if (foundProjects.length > 0) {
        let response = `🔍 **پروژه‌های یافت شده:**\n\n`;
        foundProjects.slice(0, 5).forEach((project, i) => {
          response += `${i + 1}. **${project.title}**\n`;
          response += `   • شماره قرارداد: ${project.contractNumber || 'ندارد'}\n`;
          response += `   • پیمانکار: ${project.contractor || 'ندارد'}\n`;
          response += `   • وضعیت: ${project.status === 'active' ? 'فعال' : project.status === 'completed' ? 'تکمیل شده' : 'برنامه‌ریزی'}\n`;
          response += `   • پیشرفت: ${project.progress || 0}%\n\n`;
        });
        return response;
      } else {
        if (context.projects.length > 0) {
          return `🔍 پروژه مورد نظر یافت نشد.\n\n**پروژه‌های موجود:**\n${context.projects.slice(0, 5).map((p, i) => `${i + 1}. ${p.title}`).join('\n')}\n\nاز نوار جستجو برای یافتن پروژه استفاده کنید.`;
        } else {
          return '📂 هیچ پروژه‌ای در سیستم ثبت نشده است.';
        }
      }
    }

    // پاسخ به سوالات مربوط به پیشرفت
    if (containsKeywords(lowerMessage, ['پیشرفت', 'درصد', 'progress'])) {
      if (context.projects.length === 0) {
        return '📈 هیچ پروژه‌ای در سیستم یافت نشد.';
      }
      
      const avgProgress = context.projects.reduce((sum, p) => sum + (p.progress || 0), 0) / context.projects.length;
      const maxProgress = Math.max(...context.projects.map(p => p.progress || 0));
      const minProgress = Math.min(...context.projects.map(p => p.progress || 0));
      
      return `📈 **وضعیت پیشرفت پروژه‌ها:**
      
• میانگین پیشرفت کلی: ${avgProgress.toFixed(1)}%
• بالاترین پیشرفت: ${maxProgress}%
• پایین‌ترین پیشرفت: ${minProgress}%`;
    }

    // گزارش کلی
    if (containsKeywords(lowerMessage, ['گزارش کلی', 'خلاصه', 'summary', 'overview'])) {
      const totalProjects = context.projects.length;
      const activeProjects = context.projects.filter(p => p.status === 'active').length;
      const avgProgress = context.projects.reduce((sum, p) => sum + (p.progress || 0), 0) / context.projects.length;
      const totalAmount = context.projects.reduce((sum, p) => sum + parseAmount(p.amount || ''), 0);
      
      return `📊 **گزارش کلی سیستم:**

**پروژه‌ها:**
• مجموع: ${totalProjects} پروژه
• فعال: ${activeProjects} پروژه
• میانگین پیشرفت: ${avgProgress.toFixed(1)}%
• مجموع مبلغ قراردادها: ${formatNumber(totalAmount)} ریال

**هشدارها:**
• هشدارهای باز: ${context.alerts.filter(a => a.status === 'open').length}

**مناقصات:**
• مناقصات فعال: ${context.tenders.filter(t => t.status === 'open').length}`;
    }

    // پاسخ به سوالات کلی
    if (containsKeywords(lowerMessage, ['سلام', 'hi', 'hello', 'درود'])) {
      return `سلام! 👋

من دستیار هوش مصنوعی سیستم مدیریت پروژه هستم. می‌توانم به شما در موارد زیر کمک کنم:

🔹 اطلاعات پروژه‌ها و قراردادها
🔹 وضعیت پیشرفت پیمانکاران
🔹 مجموع مبلغ قراردادها
🔹 هشدارها و مناقصه‌ها
🔹 جستجوی پروژه‌ها
🔹 گزارش‌های مالی

سوال خود را بپرسید!`;
    }

    // پاسخ پیش‌فرض
    return `متوجه سوال شما نشدم. نمونه سوالات:

• شماره قرارداد پروژه [نام] چیست؟
• پیمانکار پروژه [شماره قرارداد] کیست؟
• پیشرفت پروژه‌های سریع‌سازان البرز چقدر است؟
• مجموع مبلغ قراردادهای سال ۱۴۰۱ چقدر است?
• پروژه‌های بالای ۸۰% پیشرفت را نشان بده
• فهرست پروژه‌های راهداری قزوین را بده
• گزارش کلی سیستم را بده

یا از نوار جستجو برای یافتن پروژه‌ها استفاده کنید.`;
  } catch (error: any) {
    console.error("خطا در دستیار:", error);
    return "متأسفانه در پردازش درخواست شما خطایی رخ داد. لطفاً دوباره تلاش کنید.";
  }
}
