import { db } from "./db";
import { alerts, projects, tenders } from "@shared/schema";
import { eq, and, lt, sql } from "drizzle-orm";

export async function checkAndCreateAutoAlerts() {
  console.log("🔍 بررسی و ایجاد هشدارهای خودکار...");
  
  try {
    await checkTenderDeadlines();
    await checkProjectProgress();
    
    console.log("✅ بررسی هشدارهای خودکار با موفقیت انجام شد");
  } catch (error) {
    console.error("❌ خطا در ایجاد هشدارهای خودکار:", error);
  }
}

async function checkTenderDeadlines() {
  const now = new Date();
  const twoDaysFromNow = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000);
  
  const allTenders = await db.select().from(tenders);
  
  for (const tender of allTenders) {
    if (!tender.deadlineDate || tender.status === 'بسته شده') continue;
    
    const deadline = new Date(tender.deadlineDate);
    
    if (deadline < now && tender.status !== 'مهلت گذشته') {
      const existingAlert = await db
        .select()
        .from(alerts)
        .where(
          and(
            eq(alerts.entityType, 'tender'),
            eq(alerts.entityId, tender.id),
            eq(alerts.status, 'open')
          )
        )
        .limit(1);

      if (existingAlert.length === 0) {
        await db.insert(alerts).values({
          title: `مهلت مناقصه "${tender.title}" گذشته است`,
          description: `مناقصه "${tender.title}" در تاریخ ${tender.deadlineDate} به پایان رسیده و نیاز به بررسی دارد.`,
          severity: 'high',
          status: 'open',
          entityType: 'tender',
          entityId: tender.id,
        });
        
        console.log(`⚠️  هشدار: مهلت مناقصه "${tender.title}" گذشته است`);
      }
    }
    else if (deadline > now && deadline <= twoDaysFromNow && tender.status !== 'مهلت نزدیک') {
      const existingAlert = await db
        .select()
        .from(alerts)
        .where(
          and(
            eq(alerts.entityType, 'tender'),
            eq(alerts.entityId, tender.id),
            eq(alerts.title, `مهلت مناقصه "${tender.title}" نزدیک است`)
          )
        )
        .limit(1);

      if (existingAlert.length === 0) {
        const hoursLeft = Math.floor((deadline.getTime() - now.getTime()) / (1000 * 60 * 60));
        
        await db.insert(alerts).values({
          title: `مهلت مناقصه "${tender.title}" نزدیک است`,
          description: `${hoursLeft} ساعت تا پایان مهلت مناقصه "${tender.title}" باقی مانده است.`,
          severity: 'medium',
          status: 'open',
          entityType: 'tender',
          entityId: tender.id,
        });
        
        console.log(`🔔 هشدار: مهلت مناقصه "${tender.title}" نزدیک است (${hoursLeft} ساعت)`);
      }
    }
  }
}

async function checkProjectProgress() {
  const allProjects = await db.select().from(projects);
  
  for (const project of allProjects) {
    if (project.status !== 'active') continue;
    
    const progress = project.progress || 0;
    
    if (progress < 50) {
      const existingAlert = await db
        .select()
        .from(alerts)
        .where(
          and(
            eq(alerts.projectId, project.id),
            eq(alerts.entityType, 'project_progress'),
            eq(alerts.status, 'open')
          )
        )
        .limit(1);

      if (existingAlert.length === 0) {
        await db.insert(alerts).values({
          projectId: project.id,
          title: `پیشرفت پروژه "${project.title}" کمتر از ۵۰٪ است`,
          description: `پروژه "${project.title}" دارای ${progress}٪ پیشرفت است و نیاز به بررسی و پیگیری دارد.`,
          severity: 'low',
          status: 'open',
          entityType: 'project_progress',
          entityId: project.id,
        });
        
        console.log(`📊 هشدار: پیشرفت پروژه "${project.title}" کم است (${progress}%)`);
      }
    }
  }
}

export function startAutoAlertScheduler() {
  checkAndCreateAutoAlerts();
  
  const intervalMs = 60 * 60 * 1000;
  
  setInterval(() => {
    checkAndCreateAutoAlerts();
  }, intervalMs);
  
  console.log(`⏰ سیستم هشدارهای خودکار راه‌اندازی شد (هر ${intervalMs / 1000 / 60} دقیقه)`);
}
